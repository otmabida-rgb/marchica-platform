# Marchica Lagoon Modelling Platform

Static web platform for the TNI Program 2024 Marchica lagoon models (UM6P / ASARI with CNESTEN).
Open `index.html` through any static web host (GitHub Pages, Netlify, a university server). It needs no server code:
the spill simulator runs in JavaScript, and scenarios, sedimentation and metal prediction run the `marchica`
Python package in the browser with Pyodide (loaded from cdn.jsdelivr.net on first use).

Files: `index.html` (the platform), `data.json` (model results and station data), `wind.json` (hourly wind-driven
currents, SIMAR 2023-24), `marchica_wheel.json` (the marchica 1.0.0 package).

Embed in Google Sites: Insert > Embed > By URL > paste the page address > Whole page; resize to full width.
